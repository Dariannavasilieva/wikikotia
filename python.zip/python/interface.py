from PyQt6.QtCore import QSize, Qt
from PyQt5.QtGui import *
from PyQt6.QtWidgets import (QApplication, QWidget, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout,
                             QLabel, QTextEdit, QLineEdit, QTableWidget, QTableWidgetItem, QHeaderView,
                             QGroupBox, QRadioButton, QButtonGroup)
import sys
import re

carbohydrates = ["рис", "горох", "злаки", "пшеница", "кукуруза", "маис", "картофель", "овес", "ячмень", "сорго", "киноа"]

# Создаём виджет Qt — окно.
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Cats Food")

        self.brendNameLbl = QLabel("Введите название бренда:")
        self.lineNameLbl = QLabel("Название линейки и вкуса:")
        self.classLbl = QLabel("Введите класс корма:")
        self.ingrediensLbl = QLabel("Введите ингредиенты корма:")
        self.analisLbl = QLabel("Введите гарантированные показатели корма:")
        self.reportLbl = QLabel("Отчет:")
        self.sizeLbl = QLabel("Введите размер гранул:")
        self.noteLbl = QLabel("Введите примечание:")
        self.brendNameLine = QLineEdit()
        self.lineNameLine = QLineEdit()
        self.classLine = QLineEdit()
        self.sizeLine = QLineEdit()
        self.noteLine = QLineEdit()
        self.ingredText = QTextEdit()
        self.analisText = QTextEdit()
        self.reportText = QTextEdit()
        self.RadioGroupBox = QGroupBox("Вид корма:") # группа на экране для переключателей с ответами

        self.RadioGroup = QButtonGroup() # это для группировки переключателей, чтобы управлять их поведением

        self.rbtn_1 = QRadioButton('Для взрослых')
        self.rbtn_2 = QRadioButton('Для котят')
        self.rbtn_3 = QRadioButton('Стерилизованные,\nUrinary,\nLight')
        self.rbtn_4 = QRadioButton('Sansitive,\nHypoallergenic,\nSkin&Coat')
        self.RadioGroup.addButton(self.rbtn_1)
        self.RadioGroup.addButton(self.rbtn_2)
        self.RadioGroup.addButton(self.rbtn_3)
        self.RadioGroup.addButton(self.rbtn_4)
        self.layout_group = QHBoxLayout()
        self.layout_group.addWidget(self.rbtn_1) 
        self.layout_group.addWidget(self.rbtn_2)
        self.layout_group.addWidget(self.rbtn_3) 
        self.layout_group.addWidget(self.rbtn_4)
        self.RadioGroupBox.setLayout(self.layout_group)


        self.v1Line = QVBoxLayout() # левая вертикальная
        self.v2Line = QVBoxLayout() #правая вертикальная
        self.h1Line = QHBoxLayout() # выравнивает две предыдущие
        self.mainLine = QVBoxLayout()# главная 
        self.btnLoad = QPushButton("Загрузить")
        self.btnLoad.setMinimumHeight(70)
        self.btnLoad.setStyleSheet("QPushButton" 
                              "{"
                                "font : 20px Arial;"
                                "background-color : lightblue;"
                                "}"
                              )
      
        self.table = QTableWidget(self)  # Create a table
        self.table.setMaximumHeight(250)
        ColumNum = 26
        self.table.setColumnCount(ColumNum)     #Set three columns
        self.table.setRowCount(2) 
        
        self.table.setRowHeight(0,130)
        for i in range(ColumNum):
            self.table.horizontalHeader().setSectionResizeMode(i, QHeaderView.ResizeMode.ResizeToContents)
     
        
        self.table.setHorizontalHeaderLabels(["Бренд/направление", "Линейка/вкус", "класс", "Источник белка",
                                         "Источник жиров", "Источник углеводов", "доп.компоненты", "белки %", "жиры %",
                                         "клетчатка %", "зола %", "кальций %", "фосфор %", "коэф-т к/ф", "магний %", "натрий %", 
                                         "калий %", "Омега-3", "Омега-6", "влажность %", "углеводы %", "калорийность", 
                                         "размер гранул", "витаминная добавка", "консер-т антиокс-д", "примечания"])

        self.v1Line.addWidget(self.brendNameLbl)  
        self.v1Line.addWidget(self.brendNameLine)
        self.v1Line.addWidget(self.lineNameLbl)  
        self.v1Line.addWidget(self.lineNameLine)
        self.v1Line.addWidget(self.RadioGroupBox)
        self.v1Line.addWidget(self.classLbl)  
        self.v1Line.addWidget(self.classLine)
        self.v1Line.addWidget(self.analisLbl)  
        self.v1Line.addWidget(self.analisText)

       # self.v1Line.setSpacing(0)
        self.v1Line.addStretch()
        self.v2Line.addWidget(self.ingrediensLbl)
        self.v2Line.addWidget(self.ingredText)
        self.v2Line.addWidget(self.sizeLbl)
        self.v2Line.addWidget(self.sizeLine)
        self.v2Line.addWidget(self.noteLbl)
        self.v2Line.addWidget(self.noteLine)


        self.h1Line.addLayout(self.v1Line)
        self.h1Line.addLayout(self.v2Line)
        self.mainLine.addLayout(self.h1Line)
        self.mainLine.addWidget(self.btnLoad)
        self.mainLine.addWidget(self.table)
        

        self.mainwidget = QWidget()
        self.mainwidget.setLayout(self.mainLine)
        #self.setFixedSize(QSize(400, 300))

        # Set the central widget of the Window.
        self.setCentralWidget(self.mainwidget)
        self.setMinimumSize(1000,700)

        self.btnLoad.clicked.connect(self.btnClick)

    def btnClick(self):
        ingredients = self.ingredText.toPlainText()
        self.parsingIngredients(ingredients)
        GA = self.analisText.toPlainText()
        #self.parsingGA(GA)


    def parsingIngredients(self, ingredients):
        ingredients = ingredients.lower()
  
        ingredients = re.split(r'[;,]', ingredients) # разделить ингредиенты в список, разделитель или , или ;
        print ('список всех ингридиентов:', ingredients)
        carboList = []
        protinList = []
        fatList = []
        anotherList = []
        newIngredients = []
        # приводим строки к приличному виду
        i = 0
        maxLen = len(ingredients)
        newi = 0
        while i < maxLen:
            ingredients[i] = re.sub(r'^\s+', '', ingredients[i])
            
            if '(' in ingredients[i]:
                newIngrid = ''
                while not (')' in ingredients[i]):
                    newIngrid += ingredients[i] 
                    i +=1
                    
                newIngrid += ingredients[i]
                newIngredients.append(newIngrid)  
            else:
                newIngredients.append(ingredients[i] )  
            i+=1
            maxLen = len(ingredients)
        print(newIngredients)   
         

        for ingredient in ingredients:
            #ingredient = ingredient.lower()
            carboFlag = False
            for i in carbohydrates:
                if i in ingredient:
                    carboFlag = True
            if carboFlag:
                carboList.append(ingredient)
            elif ingredient.find("жир") != -1 or ingredient.find("масл") != -1:
                fatList.append(ingredient)
            elif ( ingredient.find("мясо") != -1 or ingredient.find("дегидр") != -1  or ingredient.find("белк") != -1 or
                    ingredient.find("глютен") != -1 or ingredient.find("яйц") != -1 or 
                    ingredient.find("обезвож") != -1 or ingredient.find("белок") != -1 ):
                protinList.append(ingredient)
            else:
                anotherList.append(ingredient)

        #----------------------------------------------------------------------------------------------
        #добавление в таблицу
        self.addToTable(protinList, 3)
        self.addToTable(fatList, 4)
        self.addToTable(carboList, 5)
        self.addToTable(anotherList, 6)
        
        
    def addToTable(self, content, rowNum):
        helpSt = ""
        n = 0
        for i in content:
            if n%2 == 0:
                helpSt += '\n'
            helpSt = helpSt + i + ', '
            n+=1
            
        helpSt=helpSt[:-2]
        self.table.setItem(0, rowNum, QTableWidgetItem(helpSt))

    def parsingGA(self, GA):
        #GA = GA.replace(';',',')
        #print(GA)
        GA = GA.lower()
        protein, fat, fiber, ash, water = [], [], [], [], []
        calc, fosf, magn, natr, kal = 0, 0, 0, 0, 0
        #----------белок----------
        if GA.find('бел') != -1:
            protein = re.findall(r'бел\w*[^A-Za-z]*?(\d+)|()', GA)[0]
            if len(re.findall(r'бел\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
                protein = re.findall(r'бел\w*[^A-Za-z]*?\d+', GA)[0]
            else:
                protein = re.findall(r'бел\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
            print(protein)
        elif GA.find('прот') != -1:
            if len(re.findall(r'бел\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
                protein = re.findall(r'прот\w*[^A-Za-z]*?\d+', GA)[0]
            else:
               
                protein = re.findall(r'прот\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
            print(protein)
        else:
            print('Значение белка не найдено в гарантированном анализе!')
        #----------жиры----------
        if GA.find('масл') != -1: 
            if len(re.findall(r'масл\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
                fat = re.findall(r'масл\w*[^A-Za-z]*?\d+', GA)[0]
                print(fat)
            else:
                fat = re.findall(r'масл\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
                print(fat)
        elif GA.find('жир') != -1: 
            if len(re.findall(r'жир\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
                fat = re.findall(r'жир\w*[^A-Za-z]*?\d+', GA)[0]
                print(fat)
            else:
                fat = re.findall(r'жир\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
                print(fat)
        else:
            print('Значение жирности не найдено в гарантированном анализе!')
        
        #----------клетчатка----------
        if GA.find('клетчат') != -1: 
            if len(re.findall(r'клетчат\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
                fiber = re.findall(r'клетчат\w*[^A-Za-z]*?\d+', GA)[0]
                print(fiber)
            else:
                fiber = re.findall(r'клетчат\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
                print(fiber)
        else:
            print('Значение клетчатки не найдено в гарантированном анализе!')

        #----------влажность----------
        if GA.find('вла') != -1: 
            if len(re.findall(r'влаж\w*[^A-Za-z]{,8}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
                water = re.findall(r'влаж\w*[^A-Za-z]*?\d+', GA)[0]
                print(water)
            else:
                water = re.findall(r'влаж\w*[^A-Za-z]{,8}?\d+[,.]\d+?', GA)[0]
                print(water)
        else:
            print("Значение влажности не найдено в гарантированном анализе!")

        #----------зольность----------
        if GA.find('зол') != -1: 
            if len(re.findall(r'зол\w*[^A-Za-z]{,8}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
                ash = re.findall(r'зол\w*[^A-Za-z]*?\d+', GA)[0]
                print(ash)
            else:
                ash = re.findall(r'зол\w*[^A-Za-z]{,8}?\d+[,.]\d+?', GA)[0]
                print(ash)
        else:
            print("Значение зольности не найдено в гарантированном анализе!")
       
        #----------кальций----------
        if len(re.findall(r'кальц\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
            calc = re.findall(r'кальц\w*[^A-Za-z]*?\d+', GA)[0]
            print(calc)
        elif len(re.findall(r'кальц\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0:
            calc = re.findall(r'кальц\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
            print(calc)
        else:
            print("Значение кальция не найдено в гарантированном анализе!")

        #----------фосфор----------
        if len(re.findall(r'фосф\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
            fosf = re.findall(r'фосф\w*[^A-Za-z]*?\d+', GA)[0]
            print(fosf)
        elif len(re.findall(r'фосф\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0:
            fosf = re.findall(r'фосф\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
            print(fosf)
        else:
            print("Значение фосфора не найдено в гарантированном анализе!")

        #----------магний----------
        if len(re.findall(r'магн\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
            magn = re.findall(r'магн\w*[^A-Za-z]*?\d+', GA)[0]
            print(magn)
        elif len(re.findall(r'магн\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0:
            magn = re.findall(r'магн\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
            print(magn)
        else:
            print("Значение магния не найдено в гарантированном анализе!")

        #----------натрий----------
        if len(re.findall(r'натр\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
            natr = re.findall(r'натр\w*[^A-Za-z]*?\d+', GA)[0]
            print(natr)
        elif len(re.findall(r'натр\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0:
            natr = re.findall(r'натр\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
            print(natr)
        else:
            print("Значение натрия не найдено в гарантированном анализе!")
        
        #----------калий----------
        if len(re.findall(r'кали\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0: # искать подстроку бел... далее символы отличные от букв, не более 5, затем дробное число
            natr = re.findall(r'кали\w*[^A-Za-z]*?\d+', GA)[0]
            print(natr)
        elif len(re.findall(r'кали\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)) == 0:
            natr = re.findall(r'кали\w*[^A-Za-z]{,5}?\d+[,.]\d+?', GA)[0]
            print(natr)
        else:
            print("Значение калий не найдено в гарантированном анализе!")

        


        
            


    
           


            






app = QApplication(sys.argv)
window = MainWindow()
window.show()  # Важно: окно по умолчанию скрыто.

app.exec()